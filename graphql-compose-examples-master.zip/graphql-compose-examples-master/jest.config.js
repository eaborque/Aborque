module.exports = {
  // moduleNameMapper: {
  //   '^app(.*)$': '<rootDir>/src$1',
  // },
  moduleFileExtensions: ['js'],
  testMatch: ['**/__tests__/**/*-test.(ts|js)'],
  roots: ['<rootDir>/examples'],
  testEnvironment: 'node',
};
